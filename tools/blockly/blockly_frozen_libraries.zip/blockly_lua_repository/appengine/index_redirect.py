print("Status: 302")
print("Location: /static/apps/code/index.html")
