This zip file contains the public and secret key for the OOBD Test user account testaccount@oobd.org

The passphrase for this account is "testtest"


This account is for test purposes ONLY, so please make sure that all scripts which are encrypted against this account
must not contain any confidential data at all!



